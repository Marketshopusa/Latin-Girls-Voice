Polyrol - TTS Service (Coqui TTS wrapper)
========================================

This repository contains a minimal TTS service based on Coqui TTS.
It is prepared to be run with Docker (optionally with NVIDIA GPU).

Structure:
- docker/Dockerfile
- docker-compose.yml
- app/main.py (FastAPI server)
- app/tts_engine.py (wrapper that loads voices from app/voices)
- app/voices/ (place voices here, each in its own folder)

Quick start (GPU):
1. Place your voice model folders under app/voices/.
2. Build and run with docker-compose:
    docker compose build
    docker compose up

Quick start (non-GPU):
- Edit docker-compose.yml to remove NVIDIA runtime lines, then build/run.

Notes:
- Coqui TTS and Torch versions must be compatible with your CUDA version if using GPU.
- Start with 1 voice and test GET /voices and POST /synthesize before adding many voices.
