import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from tts_engine import TTSEngine

VOICE_DIR = os.getenv('TTS_VOICES_DIR', './voices')
engine = TTSEngine(VOICE_DIR)

app = FastAPI(title='Polyrol TTS Service')

class SynthesisRequest(BaseModel):
    voice: str
    text: str
    speed: float = 1.0
    pitch: float = 1.0
    fmt: str = 'wav'

@app.get('/voices')
def get_voices():
    return engine.list_voices()

@app.post('/synthesize')
def synth(req: SynthesisRequest):
    try:
        out = f"/tmp/tts_{req.voice}_{abs(hash(req.text))}.{req.fmt}"
        path = engine.synthesize(voice_key=req.voice, text=req.text, speed=req.speed, pitch=req.pitch, out=out)
        return FileResponse(path, media_type='audio/wav', filename=os.path.basename(path))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
