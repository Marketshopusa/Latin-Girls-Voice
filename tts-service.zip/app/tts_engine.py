import os
import json
import tempfile
import torch
import soundfile as sf
from typing import Dict
try:
    from TTS.api import TTS
except Exception as e:
    # The TTS package must be installed; in some environments import may fail until proper torch/CUDA versions exist.
    raise

class VoiceModel:
    def __init__(self, voice_path: str):
        self.voice_path = voice_path
        meta_path = os.path.join(voice_path, "config.json")
        if not os.path.exists(meta_path):
            raise FileNotFoundError(f"Missing config.json in {voice_path}")
        with open(meta_path, 'r') as f:
            self.meta = json.load(f)
        # Load model (Coqui TTS high-level API)
        # model_name_or_path can be a local folder containing model config and weights
        self.tts = TTS(model_name_or_path=voice_path, progress_bar=False, gpu=torch.cuda.is_available())

    def synth(self, text: str, speed=1.0, pitch=1.0, output_path=None):
        if output_path is None:
            fd, output_path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
        # Many Coqui TTS models support speaker/style/speed parameters; adapt as needed.
        try:
            wav = self.tts.tts(text, speaker=self.meta.get('speaker', None), speed=speed)
        except TypeError:
            # fallback if model api does not accept speed/speaker
            wav = self.tts.tts(text)
        sf.write(output_path, wav, self.tts.synthesizer.output_sample_rate)
        return output_path

class TTSEngine:
    def __init__(self, voices_dir: str):
        self.voices_dir = voices_dir
        self.voices: Dict[str, VoiceModel] = {}
        self._load_voices()

    def _load_voices(self):
        if not os.path.isdir(self.voices_dir):
            print(f"Voices dir {self.voices_dir} not found")
            return
        for name in os.listdir(self.voices_dir):
            p = os.path.join(self.voices_dir, name)
            if os.path.isdir(p):
                try:
                    vm = VoiceModel(p)
                    self.voices[name] = vm
                    print("Loaded voice:", name)
                except Exception as e:
                    print("Failed to load voice", name, e)

    def list_voices(self):
        return {k: v.meta for k, v in self.voices.items()}

    def synthesize(self, voice_key: str, text: str, speed=1.0, pitch=1.0, out=None):
        if voice_key not in self.voices:
            raise ValueError("Voice not found")
        return self.voices[voice_key].synth(text=text, speed=speed, pitch=pitch, output_path=out)
