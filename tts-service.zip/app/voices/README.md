README - voices folder

Each subfolder inside this directory should represent one voice and contain:
- config.json  (metadata: display_name, gender, style_tags, model_file, vocoder_file, speaker)
- model files (model.pth or exported TTS package folder)
- optional samples/ (wav/mp3)

Example config.json:
{
  "display_name": "Dulce 1",
  "gender": "female",
  "style_tags": ["dulce","cálida"],
  "model_file": "model.pth",
  "vocoder_file": "vocoder.pth",
  "speaker": "speaker_1",
  "default_speed": 1.0,
  "default_pitch": 1.0
}
